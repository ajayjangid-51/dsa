## TODO
- [x] viz: add 'back to top' link next to each company
- [ ] data collection: extend scraper to collect both problem **type** and **company**
- [ ] viz: add a new 'type' column for the problem frequency table
- [ ] viz: add the 'major problem type' info for each company
- [ ] data analysis: run UMAP to on company-indexed pivot wider dataset to find clusters for company interview profiles
- [ ] refactor: convert jupyter notebook to .py file for ETL
